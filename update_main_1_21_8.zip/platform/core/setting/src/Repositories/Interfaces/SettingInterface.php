<?php

namespace Botble\Setting\Repositories\Interfaces;

use Botble\Support\Repositories\Interfaces\RepositoryInterface;

interface SettingInterface extends RepositoryInterface
{
}
